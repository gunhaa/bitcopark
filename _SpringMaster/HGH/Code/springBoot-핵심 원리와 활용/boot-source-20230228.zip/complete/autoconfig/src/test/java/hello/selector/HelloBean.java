package hello.selector;

public class HelloBean {
}
