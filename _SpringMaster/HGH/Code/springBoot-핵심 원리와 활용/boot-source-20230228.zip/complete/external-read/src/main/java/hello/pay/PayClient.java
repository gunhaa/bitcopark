package hello.pay;

public interface PayClient {
    void pay(int money);
}
